package com.selaras.circle.data

import com.selaras.circle.data.model.ActivityItem
import com.selaras.circle.data.model.Currency
import com.selaras.circle.data.model.LeaderboardEntry
import com.selaras.circle.data.model.Quest
import com.selaras.circle.data.model.ShopItem
import com.selaras.circle.data.model.UserProfile
import com.selaras.circle.data.model.WheelReward

/**
 * Static sample data standing in for a real repository/backend.
 * Swap this object for a ViewModel + data layer once you wire up
 * real storage (Room) or a network API.
 */
object SampleData {

    val me = UserProfile(
        name = "Alya Pramesti",
        handle = "@alya.pramesti",
        initials = "AP",
        level = 7,
        xp = 640,
        xpToNext = 1000,
        points = 1240,
        joinedDate = "20/11/2026",
        worksCount = 12,
        friendsCount = 18
    )

    val leaderboard = listOf(
        LeaderboardEntry(1, "Raka Nugraha", "RN", 2910),
        LeaderboardEntry(2, "Sari Melati", "SM", 2640),
        LeaderboardEntry(3, "Dewi Kirana", "DK", 2388),
        LeaderboardEntry(4, "Bima Putra", "BP", 2102),
        LeaderboardEntry(14, "Alya Pramesti (kamu)", "AP", 1240, isMe = true)
    )

    val dailyQuests = listOf(
        Quest("q1", "Unggah 1 karya baru", 50, Currency.COIN, current = 1, total = 1),
        Quest("q2", "Beri komentar ke 3 karya teman", 30, Currency.COIN, current = 2, total = 3),
        Quest("q3", "Ikuti 1 workshop komunitas", 5, Currency.GEM, current = 0, total = 1)
    )

    val shopItems = listOf(
        ShopItem("shirt", "Kaos Selaras", 1200, Currency.COIN),
        ShopItem("badge", "Lencana Edisi Khusus", 80, Currency.GEM),
        ShopItem("frame", "Bingkai Avatar Senja", 650, Currency.COIN),
        ShopItem("theme", "Tema Gelap Aurora", 45, Currency.GEM)
    )

    val recentActivity = listOf(
        ActivityItem("Dewi menyukai karyamu", "2 menit lalu"),
        ActivityItem("Workshop Cahaya & Warna dimulai besok", "Jam 19.00 WIB")
    )

    val wheelRewards = listOf(
        WheelReward("50 Koin", coins = 50),
        WheelReward("1 Permata", gems = 1),
        WheelReward("Lencana Kejutan", badge = true),
        WheelReward("100 Koin", coins = 100)
    )
}
