package com.selaras.circle.data

import com.selaras.circle.data.model.Currency
import com.selaras.circle.data.model.Quest
import com.selaras.circle.data.model.ShopItem
import com.selaras.circle.data.model.WheelReward

const val SPIN_COST = 50

/**
 * Seluruh state "ekonomi" app dalam satu objek immutable.
 * Semua fungsi di sini murni (tanpa Android/coroutine) sehingga bisa
 * di-unit-test di JVM biasa.
 *
 * Roda keberuntungan dua tahap supaya hadiah tidak "bocor" sebelum animasi selesai:
 *  1. [startSpin]  -> koin dipotong, segmen hasil ditentukan ([pendingReward]).
 *  2. [finishSpin] -> dipanggil UI setelah animasi berhenti; hadiah baru dibayarkan.
 */
data class GameState(
    val coins: Int = 3480,
    val gems: Int = 126,
    val badges: Int = 0,
    val quests: List<Quest> = SampleData.dailyQuests,
    val ownedItemIds: Set<String> = emptySet(),
    val pendingReward: Int? = null,
    val lastReward: WheelReward? = null
) {
    val canSpin: Boolean get() = coins >= SPIN_COST && pendingReward == null

    fun canAfford(item: ShopItem): Boolean = when (item.currency) {
        Currency.COIN -> coins >= item.price
        Currency.GEM -> gems >= item.price
    }

    fun claimQuest(id: String): GameState {
        val quest = quests.firstOrNull { it.id == id } ?: return this
        if (!quest.isComplete || quest.claimed) return this
        return copy(
            quests = quests.map { if (it.id == id) it.copy(claimed = true) else it },
            coins = coins + if (quest.rewardCurrency == Currency.COIN) quest.rewardAmount else 0,
            gems = gems + if (quest.rewardCurrency == Currency.GEM) quest.rewardAmount else 0
        )
    }

    fun buy(item: ShopItem): GameState {
        if (item.id in ownedItemIds || !canAfford(item)) return this
        return copy(
            coins = coins - if (item.currency == Currency.COIN) item.price else 0,
            gems = gems - if (item.currency == Currency.GEM) item.price else 0,
            ownedItemIds = ownedItemIds + item.id
        )
    }

    fun startSpin(rewardIndex: Int): GameState {
        if (!canSpin) return this
        return copy(coins = coins - SPIN_COST, pendingReward = rewardIndex, lastReward = null)
    }

    fun finishSpin(rewards: List<WheelReward> = SampleData.wheelRewards): GameState {
        val index = pendingReward ?: return this
        val reward = rewards[index]
        return copy(
            coins = coins + reward.coins,
            gems = gems + reward.gems,
            badges = badges + if (reward.badge) 1 else 0,
            pendingReward = null,
            lastReward = reward
        )
    }
}
