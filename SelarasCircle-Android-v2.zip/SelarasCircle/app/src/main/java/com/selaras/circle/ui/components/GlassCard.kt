package com.selaras.circle.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.unit.dp
import com.selaras.circle.ui.theme.BorderGlass
import com.selaras.circle.ui.theme.SurfaceGlass

/**
 * The base "pane of glass" surface used everywhere in the app: a
 * translucent fill, a hairline border, and a soft highlight at the top
 * edge to sell the idea of light hitting glass.
 */
@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    cornerRadius: Int = 20,
    padding: Int = 16,
    onClick: (() -> Unit)? = null,
    content: @Composable () -> Unit
) {
    val shape = RoundedCornerShape(cornerRadius.dp)
    val base = modifier
        .clip(shape)
        .background(
            Brush.verticalGradient(
                listOf(SurfaceGlass, SurfaceGlass)
            )
        )
        .border(BorderStroke(1.dp, BorderGlass), shape)
        .let { if (onClick != null) it.clickable(onClick = onClick) else it }
        .padding(padding.dp)

    androidx.compose.foundation.layout.Box(base) {
        content()
    }
}
