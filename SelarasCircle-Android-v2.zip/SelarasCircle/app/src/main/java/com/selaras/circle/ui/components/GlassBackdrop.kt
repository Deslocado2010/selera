package com.selaras.circle.ui.components

import androidx.compose.animation.core.InfiniteRepeatableSpec
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.asComposeRenderEffect
import androidx.compose.ui.graphics.graphicsLayer
import com.selaras.circle.ui.theme.Teal
import com.selaras.circle.ui.theme.Violet1
import com.selaras.circle.ui.theme.Violet2
import android.graphics.RenderEffect as AndroidRenderEffect
import android.os.Build

/**
 * Three soft, slowly-drifting colour blobs behind the glass cards.
 * This is what gives translucent surfaces something organic to show
 * through — the same trick the web prototype uses with CSS blur().
 *
 * Real blur() on a Composable background requires API 31+. Below that
 * we simply render the blobs unblurred at a lower alpha, which still
 * reads fine behind translucent cards.
 */
@Composable
fun GlassBackdrop(modifier: Modifier = Modifier) {
    val transition = rememberInfiniteTransition(label = "backdrop")
    val drift by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatableSpec(),
        label = "drift"
    )

    Canvas(
        modifier = modifier
            .fillMaxSize()
            .maybeBlur(60f)
    ) {
        val w = size.width
        val h = size.height

        drawCircle(
            brush = Brush.radialGradient(listOf(Violet1.copy(alpha = 0.55f), Violet1.copy(alpha = 0f))),
            radius = w * 0.45f,
            center = Offset(w * 0.1f, h * 0.05f + drift * 40f)
        )
        drawCircle(
            brush = Brush.radialGradient(listOf(Teal.copy(alpha = 0.35f), Teal.copy(alpha = 0f))),
            radius = w * 0.4f,
            center = Offset(w * 1.0f, h * 0.4f - drift * 50f)
        )
        drawCircle(
            brush = Brush.radialGradient(listOf(Violet2.copy(alpha = 0.4f), Violet2.copy(alpha = 0f))),
            radius = w * 0.38f,
            center = Offset(w * 0.2f, h * 0.95f - drift * 30f)
        )
    }
}

private fun infiniteRepeatableSpec(): InfiniteRepeatableSpec<Float> =
    infiniteRepeatable(animation = tween(durationMillis = 9000), repeatMode = RepeatMode.Reverse)

private fun Modifier.maybeBlur(radius: Float): Modifier =
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        this.graphicsLayer {
            renderEffect = AndroidRenderEffect
                .createBlurEffect(radius, radius, android.graphics.Shader.TileMode.CLAMP)
                .asComposeRenderEffect()
        }
    } else {
        this
    }
