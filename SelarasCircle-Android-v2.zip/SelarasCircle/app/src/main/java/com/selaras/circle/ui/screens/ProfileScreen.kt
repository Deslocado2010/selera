package com.selaras.circle.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.selaras.circle.data.SampleData
import com.selaras.circle.ui.components.GlassCard
import com.selaras.circle.ui.theme.*

@Composable
fun ProfileScreen(onLogout: () -> Unit) {
    val me = SampleData.me

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp)
            .padding(top = 18.dp, bottom = 120.dp)
    ) {
        GlassCard {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Avatar(me.initials)
                    Spacer(Modifier.width(14.dp))
                    Column {
                        Text(me.name, fontWeight = FontWeight.SemiBold, fontSize = 16.sp, color = TextPrimary)
                        Text(me.handle, color = TextSecondary, fontSize = 13.sp)
                    }
                }
                Spacer(Modifier.height(14.dp))
                Row {
                    Chip("${me.worksCount} karya", TextSecondary)
                    Spacer(Modifier.width(8.dp))
                    Chip("${me.friendsCount} teman", TextSecondary)
                    Spacer(Modifier.width(8.dp))
                    Chip("${me.points} poin", Gold)
                }
            }
        }

        SectionLabel("PENGATURAN")
        SettingsRow(Icons.Filled.Edit, "Edit Profil")
        SettingsRow(Icons.Filled.Notifications, "Notifikasi")
        SettingsRow(Icons.Filled.Lock, "Privasi & Keamanan")
        SettingsRow(Icons.AutoMirrored.Filled.Logout, "Keluar", onClick = onLogout)

        Spacer(Modifier.height(20.dp))
        Text(
            "Selaras Circle · tempat yang ramah untuk berkarya bersama",
            color = TextTertiary,
            fontSize = 12.sp,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
            modifier = Modifier.fillMaxWidth()
        )
    }
}

@Composable
private fun SettingsRow(icon: ImageVector, label: String, onClick: (() -> Unit)? = null) {
    GlassCard(
        cornerRadius = 16,
        padding = 14,
        onClick = onClick,
        modifier = Modifier.padding(bottom = 9.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
            IconBubble(icon)
            Spacer(Modifier.width(13.dp))
            Text(label, color = TextPrimary, fontWeight = FontWeight.SemiBold, fontSize = 14.5.sp)
        }
    }
}
