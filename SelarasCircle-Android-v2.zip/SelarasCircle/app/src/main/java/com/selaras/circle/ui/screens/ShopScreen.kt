package com.selaras.circle.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Checkroom
import androidx.compose.material.icons.filled.Circle
import androidx.compose.material.icons.filled.Diamond
import androidx.compose.material.icons.filled.MilitaryTech
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.selaras.circle.data.GameState
import com.selaras.circle.data.SampleData
import com.selaras.circle.data.model.Currency
import com.selaras.circle.data.model.ShopItem
import com.selaras.circle.ui.components.GlassCard
import com.selaras.circle.ui.theme.*

private fun iconFor(itemId: String): ImageVector = when (itemId) {
    "shirt" -> Icons.Filled.Checkroom
    "badge" -> Icons.Filled.MilitaryTech
    "frame" -> Icons.Filled.Palette
    else -> Icons.Filled.Diamond
}

@Composable
fun ShopScreen(state: GameState, onBuy: (ShopItem) -> Unit) {
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp)
            .padding(top = 18.dp, bottom = 120.dp)
    ) {
        Text("TOKO KOMUNITAS", color = TextTertiary, fontSize = 12.5.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(4.dp))
        Text("Saldo: ${state.coins} koin · ${state.gems} permata", color = TextSecondary, fontSize = 12.5.sp)
        Spacer(Modifier.height(10.dp))

        // 4 item saja, jadi dua baris Row biasa lebih ringan & tidak perlu tinggi grid yang ditebak.
        SampleData.shopItems.chunked(2).forEach { rowItems ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                rowItems.forEach { item ->
                    ShopCard(
                        item = item,
                        owned = item.id in state.ownedItemIds,
                        affordable = state.canAfford(item),
                        onBuy = { onBuy(item) },
                        modifier = Modifier.weight(1f)
                    )
                }
                if (rowItems.size == 1) Spacer(Modifier.weight(1f))
            }
            Spacer(Modifier.height(12.dp))
        }

        SectionLabel("FLASH SALE")
        GlassCard(
            modifier = Modifier.background(
                Brush.linearGradient(listOf(Violet1.copy(alpha = 0.22f), Teal.copy(alpha = 0.10f))),
                RoundedCornerShape(20.dp)
            )
        ) {
            Column {
                Text("Diskon 30% Bingkai Avatar", fontWeight = FontWeight.SemiBold, color = TextPrimary, fontSize = 15.sp)
                Spacer(Modifier.height(5.dp))
                Text("Berlaku hari ini saja, sampai tengah malam.", color = TextSecondary, fontSize = 13.sp)
            }
        }
    }
}

@Composable
private fun ShopCard(
    item: ShopItem,
    owned: Boolean,
    affordable: Boolean,
    onBuy: () -> Unit,
    modifier: Modifier = Modifier
) {
    val canBuy = !owned && affordable
    GlassCard(modifier = modifier, cornerRadius = 16, padding = 14) {
        Column(Modifier.fillMaxWidth()) {
            Box(
                Modifier
                    .fillMaxWidth()
                    .aspectRatio(1.3f)
                    .clip(RoundedCornerShape(12.dp))
                    .background(TextPrimary.copy(alpha = 0.04f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(iconFor(item.id), contentDescription = null, tint = Violet2, modifier = Modifier.size(26.dp))
            }
            Spacer(Modifier.height(10.dp))
            Text(item.name, color = TextPrimary, fontWeight = FontWeight.SemiBold, fontSize = 13.5.sp)
            Spacer(Modifier.height(4.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    if (item.currency == Currency.COIN) Icons.Filled.Circle else Icons.Filled.Diamond,
                    contentDescription = if (item.currency == Currency.COIN) "koin" else "permata",
                    tint = Gold,
                    modifier = Modifier.size(12.dp)
                )
                Spacer(Modifier.width(4.dp))
                Text("${item.price}", color = Gold, fontSize = 12.sp)
            }
            Spacer(Modifier.height(10.dp))
            val label = when {
                owned -> "Dimiliki"
                affordable -> "Beli"
                item.currency == Currency.COIN -> "Koin kurang"
                else -> "Permata kurang"
            }
            val bg = if (canBuy) Brush.horizontalGradient(listOf(Violet1, Violet2))
            else Brush.horizontalGradient(listOf(TextPrimary.copy(alpha = 0.06f), TextPrimary.copy(alpha = 0.06f)))
            Box(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(bg)
                    .clickable(enabled = canBuy, onClick = onBuy)
                    .padding(vertical = 8.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(label, color = if (canBuy) Color.White else TextTertiary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}
