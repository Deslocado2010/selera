package com.selaras.circle.navigation

sealed class Screen(val route: String) {
    data object Login : Screen("login")
    data object Home : Screen("home")
    data object Leaderboard : Screen("leaderboard")
    data object Quests : Screen("quests")
    data object Shop : Screen("shop")
    data object Profile : Screen("profile")
}

val bottomNavScreens = listOf(
    Screen.Home,
    Screen.Leaderboard,
    Screen.Quests,
    Screen.Shop,
    Screen.Profile
)
