package com.selaras.circle.data.model

data class UserProfile(
    val name: String,
    val handle: String,
    val initials: String,
    val level: Int,
    val xp: Int,
    val xpToNext: Int,
    val points: Int,
    val joinedDate: String,
    val worksCount: Int,
    val friendsCount: Int
)

data class LeaderboardEntry(
    val rank: Int,
    val name: String,
    val initials: String,
    val points: Int,
    val isMe: Boolean = false
)

enum class Currency { COIN, GEM }

data class Quest(
    val id: String,
    val title: String,
    val rewardAmount: Int,
    val rewardCurrency: Currency,
    val current: Int,
    val total: Int,
    val claimed: Boolean = false
) {
    val progress: Float get() = (current.toFloat() / total.toFloat()).coerceIn(0f, 1f)
    val isComplete: Boolean get() = current >= total
}

data class ShopItem(
    val id: String,
    val name: String,
    val price: Int,
    val currency: Currency
)

data class ActivityItem(
    val title: String,
    val subtitle: String
)

/** Satu segmen roda keberuntungan. Urutannya = urutan segmen di Canvas (searah jarum jam dari jam 3). */
data class WheelReward(
    val label: String,
    val coins: Int = 0,
    val gems: Int = 0,
    val badge: Boolean = false
)
