package com.selaras.circle.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.Star
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.selaras.circle.data.GameViewModel
import com.selaras.circle.ui.components.GlassBackdrop
import com.selaras.circle.ui.components.GlassBottomNav
import com.selaras.circle.ui.components.NavTab
import com.selaras.circle.ui.theme.BgDeep
import kotlinx.coroutines.launch

private val tabs = listOf(
    NavTab(Icons.Filled.Home, "Beranda"),
    NavTab(Icons.Filled.EmojiEvents, "Peringkat"),
    NavTab(Icons.Filled.Star, "Misi"),
    NavTab(Icons.Filled.ShoppingCart, "Toko"),
    NavTab(Icons.Filled.Person, "Profil")
)

/**
 * The main app shell: a 5-page HorizontalPager (swipe left/right, same as
 * the web prototype) with a glass bottom nav whose pill indicator stays in
 * sync with the page you're on, however you got there.
 *
 * State koin/permata/misi/toko dipegang [GameViewModel] di sini lalu
 * diturunkan ke tiap halaman (state hoisting), jadi tidak hilang saat rotasi.
 */
@Composable
fun MainAppScreen(onLogout: () -> Unit) {
    val pagerState = rememberPagerState(pageCount = { tabs.size })
    val scope = rememberCoroutineScope()
    val viewModel: GameViewModel = viewModel()
    val state by viewModel.state.collectAsStateWithLifecycle()

    Box(modifier = Modifier.fillMaxSize().background(BgDeep)) {
        GlassBackdrop()

        Column(Modifier.fillMaxSize()) {
            HorizontalPager(
                state = pagerState,
                modifier = Modifier.weight(1f)
            ) { page ->
                when (page) {
                    0 -> HomeScreen()
                    1 -> LeaderboardScreen()
                    2 -> QuestsScreen(
                        state = state,
                        onClaim = viewModel::claimQuest,
                        onSpin = viewModel::startSpin,
                        onSpinFinished = viewModel::finishSpin
                    )
                    3 -> ShopScreen(state = state, onBuy = viewModel::buy)
                    4 -> ProfileScreen(onLogout = onLogout)
                }
            }
        }

        GlassBottomNav(
            tabs = tabs,
            selectedIndex = pagerState.currentPage,
            onSelect = { index ->
                scope.launch { pagerState.animateScrollToPage(index) }
            },
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 14.dp)
        )
    }
}
