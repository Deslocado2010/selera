package com.selaras.circle.ui.screens

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Circle
import androidx.compose.material.icons.filled.Diamond
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.selaras.circle.data.GameState
import com.selaras.circle.data.SPIN_COST
import com.selaras.circle.data.SampleData
import com.selaras.circle.data.model.Currency
import com.selaras.circle.data.model.Quest
import com.selaras.circle.ui.components.GlassCard
import com.selaras.circle.ui.components.GradientButton
import com.selaras.circle.ui.theme.*
import kotlin.random.Random

private val wheelColors = listOf(Violet1, Teal, Violet2, Gold)

@Composable
fun QuestsScreen(
    state: GameState,
    onClaim: (String) -> Unit,
    onSpin: () -> Unit,
    onSpinFinished: () -> Unit
) {
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp)
            .padding(top = 18.dp, bottom = 120.dp)
    ) {
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            WalletChip(Icons.Filled.Circle, "${state.coins}", "Koin", Gold, Modifier.weight(1f))
            WalletChip(Icons.Filled.Diamond, "${state.gems}", "Permata", Teal, Modifier.weight(1f))
        }

        SectionLabel("MISI HARIAN")
        state.quests.forEach { quest ->
            QuestRow(quest = quest, onClaim = { onClaim(quest.id) })
            Spacer(Modifier.height(10.dp))
        }

        SectionLabel("RODA KEBERUNTUNGAN")
        LuckWheel(state = state, onSpin = onSpin, onSpinFinished = onSpinFinished)
    }
}

@Composable
private fun WalletChip(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    amount: String,
    label: String,
    tint: Color,
    modifier: Modifier = Modifier
) {
    GlassCard(modifier = modifier, cornerRadius = 16, padding = 14) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier
                    .size(32.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(tint.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(16.dp))
            }
            Spacer(Modifier.width(10.dp))
            Column {
                Text(amount, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                Text(label, color = TextTertiary, fontSize = 11.sp)
            }
        }
    }
}

@Composable
private fun QuestRow(quest: Quest, onClaim: () -> Unit) {
    val claimable = quest.isComplete && !quest.claimed
    GlassCard(cornerRadius = 16, padding = 14) {
        Column {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(quest.title, color = TextPrimary, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, modifier = Modifier.weight(1f))
                Spacer(Modifier.width(8.dp))
                Text(
                    "+${quest.rewardAmount} ${if (quest.rewardCurrency == Currency.COIN) "koin" else "permata"}",
                    color = Gold, fontSize = 12.sp
                )
            }
            Spacer(Modifier.height(9.dp))
            ProgressTrack(progress = quest.progress)
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                val label = when {
                    quest.claimed -> "Diklaim"
                    quest.isComplete -> "Klaim"
                    else -> "${quest.current} / ${quest.total}"
                }
                val bg = if (claimable) Brush.horizontalGradient(listOf(Violet1, Violet2))
                else Brush.horizontalGradient(listOf(TextPrimary.copy(alpha = 0.06f), TextPrimary.copy(alpha = 0.06f)))
                Box(
                    Modifier
                        .clip(RoundedCornerShape(999.dp))
                        .background(bg)
                        .clickable(enabled = claimable, onClick = onClaim)
                        .padding(horizontal = 14.dp, vertical = 6.dp)
                ) {
                    Text(
                        label,
                        color = if (claimable) Color.White else TextTertiary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

/**
 * Roda 4 segmen. Segmen ke-i (0..3) mulai di sudut 90*i dan menyapu 90 derajat
 * (0 derajat = jam 3, searah jarum jam). Penunjuk ada di jam 12 (270 derajat).
 * Agar segmen hasil berhenti tepat di bawah penunjuk, sudut akhir roda dihitung
 * dari `pendingReward` milik state — bukan dari angka acak terpisah.
 */
@Composable
private fun LuckWheel(state: GameState, onSpin: () -> Unit, onSpinFinished: () -> Unit) {
    val rotation = remember { Animatable(0f) }
    val pending = state.pendingReward
    val spinning = pending != null

    // Jika layar berotasi di tengah putaran, pendingReward masih ada di ViewModel,
    // jadi efek ini jalan lagi dan putaran diulang sampai selesai (tanpa kehilangan hadiah).
    LaunchedEffect(pending) {
        if (pending != null) {
            val jitter = Random.nextInt(-30, 31)
            val stopAngle = (((270f - (90f * pending + 45f + jitter)) % 360f) + 360f) % 360f
            rotation.snapTo(rotation.value % 360f)
            rotation.animateTo(5 * 360f + stopAngle, tween(2800, easing = FastOutSlowInEasing))
            onSpinFinished()
        }
    }

    GlassCard {
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
            Box(Modifier.padding(top = 8.dp).size(150.dp), contentAlignment = Alignment.Center) {
                Canvas(modifier = Modifier.fillMaxSize().rotate(rotation.value)) {
                    wheelColors.forEachIndexed { i, color ->
                        drawArc(color = color, startAngle = i * 90f, sweepAngle = 90f, useCenter = true)
                    }
                    drawCircle(
                        color = BgDeep,
                        radius = size.minDimension / 5.5f,
                        style = Stroke(width = 1.dp.toPx())
                    )
                }
                Box(
                    Modifier.size(46.dp).clip(RoundedCornerShape(50)).background(BgDeep),
                    contentAlignment = Alignment.Center
                ) {
                    Text("PUTAR", color = TextPrimary, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
                // Penunjuk di jam 12
                Canvas(Modifier.size(18.dp).align(Alignment.TopCenter).offset(y = (-8).dp)) {
                    val path = Path().apply {
                        moveTo(0f, 0f)
                        lineTo(size.width, 0f)
                        lineTo(size.width / 2f, size.height)
                        close()
                    }
                    drawPath(path, TextPrimary)
                }
            }

            Spacer(Modifier.height(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                SampleData.wheelRewards.forEachIndexed { i, reward ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(8.dp).clip(RoundedCornerShape(50)).background(wheelColors[i]))
                        Spacer(Modifier.width(4.dp))
                        Text(reward.label, color = TextTertiary, fontSize = 10.sp)
                    }
                }
            }

            Spacer(Modifier.height(14.dp))
            GradientButton(
                text = "Putar ($SPIN_COST koin)",
                modifier = Modifier.fillMaxWidth(0.8f),
                enabled = state.canSpin,
                onClick = onSpin
            )
            Spacer(Modifier.height(10.dp))
            val resultText = when {
                spinning -> "Memutar..."
                state.lastReward != null -> "Kamu dapat: ${state.lastReward.label} 🎉"
                state.coins < SPIN_COST -> "Koin belum cukup untuk memutar."
                else -> ""
            }
            Text(resultText, color = TextSecondary, fontSize = 13.sp)
            if (state.badges > 0) {
                Text("Lencana kejutan terkumpul: ${state.badges}", color = Gold, fontSize = 12.sp)
            }
        }
    }
}
