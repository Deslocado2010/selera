package com.selaras.circle.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.selaras.circle.ui.components.GlassBackdrop
import com.selaras.circle.ui.components.GlassCard
import com.selaras.circle.ui.components.GlassTextField
import com.selaras.circle.ui.components.GradientButton
import com.selaras.circle.ui.theme.*

private enum class AuthTab { LOGIN, REGISTER }

@Composable
fun LoginScreen(onLoggedIn: () -> Unit) {
    var tab by rememberSaveable { mutableStateOf(AuthTab.LOGIN) }
    var username by rememberSaveable { mutableStateOf("") }
    // Password sengaja pakai remember biasa: tidak ditulis ke saved-state Bundle.
    var password by remember { mutableStateOf("") }
    var showPassword by rememberSaveable { mutableStateOf(false) }
    var rememberMe by rememberSaveable { mutableStateOf(false) }

    Box(modifier = Modifier.fillMaxSize().background(BgDeep)) {
        GlassBackdrop()

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .padding(bottom = 32.dp),
        ) {
            Spacer(Modifier.height(56.dp))

            // Hero mark + title
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                Box(
                    modifier = Modifier
                        .size(56.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(Brush.linearGradient(listOf(Violet1, Teal))),
                    contentAlignment = Alignment.Center
                ) {
                    Text("✦", fontSize = 24.sp)
                }
                Spacer(Modifier.height(18.dp))
                Text("Selaras Circle", style = MaterialTheme.typography.headlineSmall, color = TextPrimary)
                Spacer(Modifier.height(4.dp))
                Text("Komunitas hobi & teman sefrekuensi", color = TextSecondary, fontSize = 14.sp)
            }

            Spacer(Modifier.height(28.dp))

            // Login / Register tab switcher
            GlassCard(cornerRadius = 16, padding = 5) {
                Row(Modifier.fillMaxWidth()) {
                    AuthTabButton("Masuk", tab == AuthTab.LOGIN, Modifier.weight(1f)) { tab = AuthTab.LOGIN }
                    AuthTabButton("Daftar", tab == AuthTab.REGISTER, Modifier.weight(1f)) { tab = AuthTab.REGISTER }
                }
            }

            Spacer(Modifier.height(18.dp))

            Text("Username", color = TextSecondary, fontSize = 13.sp)
            Spacer(Modifier.height(7.dp))
            GlassTextField(
                value = username,
                onValueChange = { username = it },
                label = "Nama pengguna kamu",
                leadingIcon = Icons.Filled.Person,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(Modifier.height(16.dp))

            Text("Kata sandi", color = TextSecondary, fontSize = 13.sp)
            Spacer(Modifier.height(7.dp))
            GlassTextField(
                value = password,
                onValueChange = { password = it },
                label = "Kata sandi",
                leadingIcon = Icons.Filled.Lock,
                isPassword = !showPassword,
                modifier = Modifier.fillMaxWidth(),
                trailing = {
                    IconButton(onClick = { showPassword = !showPassword }) {
                        Icon(
                            imageVector = if (showPassword) Icons.Filled.VisibilityOff else Icons.Filled.Visibility,
                            contentDescription = null,
                            tint = TextTertiary
                        )
                    }
                }
            )

            Spacer(Modifier.height(16.dp))

            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Switch(checked = rememberMe, onCheckedChange = { rememberMe = it })
                    Spacer(Modifier.width(8.dp))
                    Text("Ingat saya", color = TextSecondary, fontSize = 14.sp)
                }
                Text("Lupa sandi?", color = Violet2, fontSize = 13.sp)
            }

            Spacer(Modifier.height(22.dp))

            GradientButton(text = if (tab == AuthTab.LOGIN) "Masuk" else "Daftar", onClick = onLoggedIn)

            Spacer(Modifier.height(22.dp))

            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                HorizontalDivider(Modifier.weight(1f), color = BorderGlass)
                Text("  atau  ", color = TextTertiary, fontSize = 13.sp)
                HorizontalDivider(Modifier.weight(1f), color = BorderGlass)
            }

            Spacer(Modifier.height(18.dp))

            GlassCard(cornerRadius = 16, padding = 15, onClick = { tab = AuthTab.REGISTER }) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                    Text("Buat akun baru", color = TextPrimary, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                }
            }

            Spacer(Modifier.height(20.dp))
            Text(
                "Dengan masuk, kamu menyetujui pedoman komunitas yang ramah dan saling menghormati.",
                color = TextTertiary,
                fontSize = 12.5.sp,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

@Composable
private fun AuthTabButton(label: String, selected: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(12.dp)
    Box(
        modifier = modifier
            .clip(shape)
            .background(if (selected) Brush.horizontalGradient(listOf(Violet1, Violet2)) else Brush.horizontalGradient(listOf(androidx.compose.ui.graphics.Color.Transparent, androidx.compose.ui.graphics.Color.Transparent)))
            .clickable(onClick = onClick)
            .padding(vertical = 10.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(label, color = if (selected) androidx.compose.ui.graphics.Color.White else TextTertiary, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
    }
}
