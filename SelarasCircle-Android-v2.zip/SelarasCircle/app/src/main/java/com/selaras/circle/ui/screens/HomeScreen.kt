package com.selaras.circle.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Checkroom
import androidx.compose.material.icons.filled.Diversity3
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.selaras.circle.data.SampleData
import com.selaras.circle.ui.components.GlassCard
import com.selaras.circle.ui.theme.*

@Composable
fun HomeScreen() {
    val me = SampleData.me

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp)
            .padding(top = 18.dp, bottom = 120.dp)
    ) {
        Column {
            Text("Selamat datang kembali", color = TextTertiary, fontSize = 13.sp)
            Text(me.name, style = MaterialTheme.typography.titleMedium, color = TextPrimary)
        }

        Spacer(Modifier.height(16.dp))

        GlassCard {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Avatar(me.initials)
                    Spacer(Modifier.width(14.dp))
                    Column {
                        Text(me.name, fontWeight = FontWeight.SemiBold, fontSize = 16.sp, color = TextPrimary)
                        Text("Pelukis Komunitas · Level ${me.level}", color = Teal, fontSize = 13.sp)
                    }
                }
                Spacer(Modifier.height(14.dp))
                Row {
                    Chip("★ ${me.points} poin", Gold)
                    Spacer(Modifier.width(8.dp))
                    Chip("Bergabung ${me.joinedDate}", TextSecondary)
                    Spacer(Modifier.width(8.dp))
                    Chip("${me.worksCount} karya", TextSecondary)
                }
                Spacer(Modifier.height(14.dp))
                Column {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Menuju Level ${me.level + 1}", color = TextSecondary, fontSize = 12.5.sp)
                        Text("${me.xp} / ${me.xpToNext} XP", color = TextSecondary, fontSize = 12.5.sp)
                    }
                    Spacer(Modifier.height(7.dp))
                    ProgressTrack(progress = me.xp.toFloat() / me.xpToNext.toFloat())
                }
            }
        }

        Spacer(Modifier.height(16.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            QuickTile(Icons.Filled.CalendarMonth, "Acara", Modifier.weight(1f))
            QuickTile(Icons.Filled.Chat, "Obrolan", Modifier.weight(1f))
            QuickTile(Icons.Filled.Diversity3, "Teman", Modifier.weight(1f))
            QuickTile(Icons.Filled.Checkroom, "Check-in", Modifier.weight(1f))
        }

        SectionLabel("SOROTAN")
        GlassCard(
            modifier = Modifier.background(
                Brush.linearGradient(listOf(Violet1.copy(alpha = 0.22f), Teal.copy(alpha = 0.10f))),
                RoundedCornerShape(20.dp)
            )
        ) {
            Column {
                Text("Tantangan Minggu Ini: Sketsa Senja", fontWeight = FontWeight.SemiBold, color = TextPrimary, fontSize = 15.sp)
                Spacer(Modifier.height(5.dp))
                Text(
                    "Unggah karya bertema \"senja\" sebelum Minggu untuk memperebutkan lencana edisi terbatas.",
                    color = TextSecondary, fontSize = 13.sp
                )
            }
        }

        SectionLabel("AKTIVITAS TERBARU")
        SampleData.recentActivity.forEach { activity ->
            GlassCard(modifier = Modifier.padding(bottom = 9.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconBubble(Icons.Filled.Favorite)
                    Spacer(Modifier.width(13.dp))
                    Column {
                        Text(activity.title, fontWeight = FontWeight.SemiBold, fontSize = 14.5.sp, color = TextPrimary)
                        Text(activity.subtitle, color = TextTertiary, fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun SectionLabel(text: String) {
    Spacer(Modifier.height(22.dp))
    Text(text, color = TextTertiary, fontSize = 12.5.sp, fontWeight = FontWeight.SemiBold)
    Spacer(Modifier.height(10.dp))
}

@Composable
fun Avatar(initials: String, size: androidx.compose.ui.unit.Dp = 52.dp) {
    Box(
        Modifier
            .size(size)
            .clip(RoundedCornerShape(16.dp))
            .background(Brush.linearGradient(listOf(Violet1, Teal))),
        contentAlignment = Alignment.Center
    ) {
        Text(initials, color = BgDeep, fontWeight = FontWeight.Bold, fontSize = 16.sp)
    }
}

@Composable
fun Chip(text: String, textColor: androidx.compose.ui.graphics.Color) {
    Box(
        Modifier
            .clip(RoundedCornerShape(999.dp))
            .background(TextPrimary.copy(alpha = 0.04f))
            .padding(horizontal = 12.dp, vertical = 6.dp)
    ) {
        Text(text, color = textColor, fontSize = 12.5.sp)
    }
}

@Composable
fun ProgressTrack(progress: Float) {
    Box(
        Modifier
            .fillMaxWidth()
            .height(7.dp)
            .clip(RoundedCornerShape(999.dp))
            .background(TextPrimary.copy(alpha = 0.07f))
    ) {
        Box(
            Modifier
                .fillMaxHeight()
                .fillMaxWidth(progress.coerceIn(0f, 1f))
                .clip(RoundedCornerShape(999.dp))
                .background(Brush.horizontalGradient(listOf(Violet1, Teal)))
        )
    }
}

@Composable
fun IconBubble(icon: ImageVector) {
    Box(
        Modifier
            .size(38.dp)
            .clip(RoundedCornerShape(11.dp))
            .background(TextPrimary.copy(alpha = 0.05f)),
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, contentDescription = null, tint = Violet2, modifier = Modifier.size(18.dp))
    }
}

@Composable
private fun QuickTile(icon: ImageVector, label: String, modifier: Modifier = Modifier) {
    GlassCard(modifier = modifier, cornerRadius = 16, padding = 12) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
            IconBubble(icon)
            Spacer(Modifier.height(8.dp))
            Text(label, color = TextSecondary, fontSize = 11.5.sp)
        }
    }
}
