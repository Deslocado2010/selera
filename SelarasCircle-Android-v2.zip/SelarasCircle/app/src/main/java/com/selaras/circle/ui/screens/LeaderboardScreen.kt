package com.selaras.circle.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MilitaryTech
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.selaras.circle.data.SampleData
import com.selaras.circle.data.model.LeaderboardEntry
import com.selaras.circle.ui.components.GlassCard
import com.selaras.circle.ui.theme.*

@Composable
fun LeaderboardScreen() {
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp)
            .padding(top = 18.dp, bottom = 120.dp)
    ) {
        Text("PAPAN PERINGKAT MINGGU INI", color = TextTertiary, fontSize = 12.5.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(10.dp))

        SampleData.leaderboard.forEach { entry ->
            LeaderboardRow(entry)
            Spacer(Modifier.height(8.dp))
        }

        SectionLabel("LENCANA KOMUNITAS")
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
            BadgeTile(Icons.Filled.EmojiEvents, unlocked = true, Modifier.weight(1f))
            BadgeTile(Icons.Filled.MilitaryTech, unlocked = true, Modifier.weight(1f))
            BadgeTile(Icons.Filled.Lock, unlocked = false, Modifier.weight(1f))
            BadgeTile(Icons.Filled.Lock, unlocked = false, Modifier.weight(1f))
        }
    }
}

@Composable
private fun LeaderboardRow(entry: LeaderboardEntry) {
    val shape = RoundedCornerShape(14.dp)
    GlassCard(
        cornerRadius = 14,
        padding = 12,
        modifier = if (entry.isMe) Modifier.border(BorderStroke(1.dp, Violet2), shape) else Modifier
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
            Text(
                "${entry.rank}",
                color = if (entry.rank == 1) Gold else TextSecondary,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                modifier = Modifier.width(26.dp)
            )
            Spacer(Modifier.width(8.dp))
            Avatar(entry.initials, size = 36.dp)
            Spacer(Modifier.width(12.dp))
            Text(entry.name, color = TextPrimary, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, modifier = Modifier.weight(1f))
            Text("${entry.points}", color = Gold, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
        }
    }
}

@Composable
private fun BadgeTile(icon: androidx.compose.ui.graphics.vector.ImageVector, unlocked: Boolean, modifier: Modifier = Modifier) {
    GlassCard(modifier = modifier.aspectRatio(1f), cornerRadius = 16, padding = 0) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Icon(
                icon,
                contentDescription = null,
                tint = if (unlocked) Gold else TextTertiary,
                modifier = Modifier.size(22.dp)
            )
        }
    }
}
