package com.selaras.circle.ui.theme

import androidx.compose.ui.graphics.Color

// Core "liquid glass" palette — ported from the Selaras Circle web prototype.
val BgDeep = Color(0xFF0A0816)
val SurfaceGlass = Color(0x0FFFFFFF)       // ~6% white, used as glass card fill
val SurfaceGlassStrong = Color(0x17FFFFFF) // ~9% white
val BorderGlass = Color(0x1CFFFFFF)        // ~11% white border

val TextPrimary = Color(0xFFF3F1FA)
val TextSecondary = Color(0xFFAFA9C7)
val TextTertiary = Color(0xFF776F93)

val Violet1 = Color(0xFF7C5CFC)
val Violet2 = Color(0xFFB98CFF)
val Teal = Color(0xFF5CE3C9)
val Gold = Color(0xFFF6C76B)
val Danger = Color(0xFFFF6B6B)
