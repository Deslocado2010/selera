package com.selaras.circle.ui.components

import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import com.selaras.circle.ui.theme.BgDeep
import com.selaras.circle.ui.theme.BorderGlass
import com.selaras.circle.ui.theme.TextPrimary
import com.selaras.circle.ui.theme.TextTertiary
import com.selaras.circle.ui.theme.Violet1
import com.selaras.circle.ui.theme.Violet2

data class NavTab(val icon: ImageVector, val label: String)

private val TAB_WIDTH = 58.dp

@Composable
fun GlassBottomNav(
    tabs: List<NavTab>,
    selectedIndex: Int,
    onSelect: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val pillOffset by animateDpAsState(
        targetValue = TAB_WIDTH * selectedIndex,
        animationSpec = tween(durationMillis = 350),
        label = "navPill"
    )

    Row(
        modifier = modifier
            .clip(RoundedCornerShape(22.dp))
            .background(BgDeep.copy(alpha = 0.72f))
            .border(1.dp, BorderGlass, RoundedCornerShape(22.dp))
            .padding(7.dp)
    ) {
        Box {
            Box(
                Modifier
                    .offset(x = pillOffset)
                    .size(width = TAB_WIDTH, height = 48.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Brush.horizontalGradient(listOf(Violet1, Violet2)))
            )
            Row {
                tabs.forEachIndexed { index, tab ->
                    val selected = index == selectedIndex
                    Box(
                        modifier = Modifier
                            .size(width = TAB_WIDTH, height = 48.dp)
                            .clickable(onClick = { onSelect(index) }),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = tab.icon,
                            contentDescription = tab.label,
                            tint = if (selected) TextPrimary else TextTertiary
                        )
                    }
                }
            }
        }
    }
}
