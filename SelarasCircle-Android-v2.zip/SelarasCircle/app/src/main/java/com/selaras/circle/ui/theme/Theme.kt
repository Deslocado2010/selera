package com.selaras.circle.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val SelarasColorScheme = darkColorScheme(
    primary = Violet1,
    secondary = Teal,
    tertiary = Gold,
    background = BgDeep,
    surface = BgDeep,
    onBackground = TextPrimary,
    onSurface = TextPrimary,
    error = Danger
)

/**
 * Selaras Circle is deliberately dark-only — the "liquid glass" look is
 * built around translucent panels on a near-black backdrop, so this theme
 * does not branch on the system's light/dark setting.
 */
@Composable
fun SelarasCircleTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = SelarasColorScheme,
        typography = SelarasTypography,
        content = content
    )
}
