package com.selaras.circle.data

import androidx.lifecycle.ViewModel
import com.selaras.circle.data.model.ShopItem
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlin.random.Random

/**
 * Pemegang state app. Bertahan saat rotasi layar/perubahan konfigurasi.
 * Belum bertahan saat proses app dimatikan sistem atau app ditutup —
 * itu tahap berikutnya (Room).
 *
 * Dipanggil hanya dari main thread (event UI), jadi baca-lalu-tulis
 * pada `_state.value` aman.
 */
class GameViewModel : ViewModel() {

    private val _state = MutableStateFlow(GameState())
    val state: StateFlow<GameState> = _state.asStateFlow()

    fun claimQuest(id: String) {
        _state.value = _state.value.claimQuest(id)
    }

    fun buy(item: ShopItem) {
        _state.value = _state.value.buy(item)
    }

    fun startSpin() {
        val s = _state.value
        if (!s.canSpin) return
        _state.value = s.startSpin(Random.nextInt(SampleData.wheelRewards.size))
    }

    fun finishSpin() {
        _state.value = _state.value.finishSpin()
    }
}
