package com.selaras.circle

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.selaras.circle.navigation.SelarasNavGraph
import com.selaras.circle.ui.theme.BgDeep
import com.selaras.circle.ui.theme.SelarasCircleTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            SelarasCircleTheme {
                Surface(modifier = Modifier.fillMaxSize(), color = BgDeep) {
                    SelarasNavGraph()
                }
            }
        }
    }
}
