package com.selaras.circle.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class GameStateTest {

    private val shirt = SampleData.shopItems.first { it.id == "shirt" }   // 1200 koin
    private val gemBadge = SampleData.shopItems.first { it.id == "badge" } // 80 permata

    @Test fun claimQuest_incomplete_isNoOp() {
        val s = GameState()
        assertEquals(s, s.claimQuest("q2")) // 2/3
    }

    @Test fun claimQuest_complete_paysOnce() {
        val once = GameState().claimQuest("q1")
        assertEquals(3480 + 50, once.coins)
        assertTrue(once.quests.first { it.id == "q1" }.claimed)
        assertEquals(once.coins, once.claimQuest("q1").coins) // klaim kedua tidak menambah
    }

    @Test fun buy_insufficientFunds_isNoOp() {
        val s = GameState(coins = 10)
        assertEquals(s, s.buy(shirt))
    }

    @Test fun buy_deductsAndMarksOwned_andCannotRebuy() {
        val bought = GameState().buy(shirt)
        assertEquals(3480 - 1200, bought.coins)
        assertTrue("shirt" in bought.ownedItemIds)
        assertEquals(bought, bought.buy(shirt))
    }

    @Test fun buy_gemItem_usesGems() {
        val bought = GameState().buy(gemBadge)
        assertEquals(126 - 80, bought.gems)
        assertEquals(3480, bought.coins)
    }

    @Test fun spin_chargesImmediately_paysOnFinish() {
        val started = GameState().startSpin(3) // "100 Koin"
        assertEquals(3480 - SPIN_COST, started.coins)
        assertEquals(3, started.pendingReward)
        val done = started.finishSpin()
        assertEquals(3480 - SPIN_COST + 100, done.coins)
        assertNull(done.pendingReward)
        assertEquals("100 Koin", done.lastReward?.label)
    }

    @Test fun spin_cannotStartWhilePendingOrBroke() {
        val pending = GameState().startSpin(0)
        assertEquals(pending, pending.startSpin(1))
        val broke = GameState(coins = SPIN_COST - 1)
        assertEquals(broke, broke.startSpin(0))
    }

    @Test fun spin_badgeReward_incrementsBadges() {
        val done = GameState().startSpin(2).finishSpin() // "Lencana Kejutan"
        assertEquals(1, done.badges)
    }
}
