# Selaras Circle — Android (Jetpack Compose)

Aplikasi komunitas hobi dengan tampilan "liquid glass": kartu kaca blur,
blob gradient yang melayang pelan di background, dan navigasi bawah
dengan pill indikator yang geser smooth saat swipe antar tab.

**Tahap 2 (versi ini):** state koin/permata/misi/toko sekarang dipegang
`GameViewModel` sehingga bertahan saat layar dirotasi. Roda keberuntungan
dan Toko sudah benar-benar mengubah saldo. Belum ada backend/login
sungguhan, penyimpanan permanen, atau API — state masih di memori dan
akan reset saat app ditutup (tahap berikutnya: Room).

## Arsitektur & asumsi

- **Bahasa/UI:** Kotlin + Jetpack Compose + Navigation-Compose.
- **minSdk 24 / targetSdk 34 / compileSdk 34**, Kotlin 1.9.24, AGP 8.5.2.
- Struktur: `ui/theme` (warna & tipografi), `ui/components` (kartu kaca,
  tombol gradient, text field, bottom nav), `ui/screens` (5 tab + login),
  `navigation` (routing), `data` (model + data contoh).
- Blur asli (`RenderEffect`) hanya aktif di **Android 12 (API 31) ke
  atas**; di bawah itu, blob background tampil tanpa blur tapi tetap
  terlihat wajar karena alpha-nya sudah rendah.

## Yang berubah di tahap 2

**Perbaikan bug dari baseline (akan menggagalkan build):**
- `AndroidManifest.xml`: namespace `android` salah (`res/auto` → `res/android`).
- `LeaderboardScreen.kt` dan `ShopScreen.kt`: memakai `Text` tanpa import.
- Ikon launcher `@mipmap/ic_launcher` tidak ada di paket → diganti
  `res/drawable/ic_launcher.xml` (vector sederhana) agar paket ini mandiri.

**Fitur / arsitektur:**
- `data/GameState.kt` — logika murni (klaim misi, beli, putar roda), bisa di-unit-test.
- `data/GameViewModel.kt` — pembungkus `StateFlow`, di-scope ke back-stack entry Beranda.
- `MainAppScreen` mengambil state via `collectAsStateWithLifecycle()` dan
  menurunkannya ke layar (state hoisting).
- **Roda keberuntungan:** koin dipotong saat mulai, hadiah dibayar setelah
  animasi berhenti, dan segmen yang berhenti di penunjuk = hadiah yang
  didapat (sebelumnya hadiah acak terpisah dari gambar roda). Lencana
  kejutan dihitung. Jika layar dirotasi di tengah putaran, putaran diulang
  sampai selesai tanpa kehilangan hadiah.
- **Toko:** tombol Beli / Dimiliki / Koin kurang, saldo dipotong, item tidak
  bisa dibeli dua kali. Grid fixed-height diganti kolom yang bisa di-scroll
  (sebelumnya konten bawah bisa terpotong).
- **Login:** tab/username/"ingat saya" bertahan saat rotasi. Password
  **sengaja tidak** disimpan ke saved-state.
- `GradientButton` punya parameter `enabled`.
- Dependency baru: `lifecycle-viewmodel-compose`, `lifecycle-runtime-compose`
  (2.8.4, satu versi dengan lifecycle lainnya), dan `junit` untuk unit test.

## ⚠️ Catatan penting soal environment: Android IDE di HP

Kamu pilih "Android IDE di HP". Beberapa hal untuk diperhatikan:

1. **Compiler plugin Compose itu berat.** Build pertama kali akan
   mengunduh banyak dependency (Compose BOM, Navigation, Material Icons
   Extended) — pastikan koneksi stabil dan storage cukup (siapkan
   minimal ~2–3 GB ruang kosong untuk cache Gradle).
2. **`kotlinCompilerExtensionVersion` di `app/build.gradle.kts` harus
   cocok dengan versi Kotlin yang dipakai IDE kamu.** Aku set ke
   `1.5.14` untuk Kotlin `1.9.24`. Kalau Android IDE kamu membundel
   versi Kotlin lain, cek tabel kompatibilitas di
   developer.android.com/jetpack/androidx/releases/compose-kotlin dan
   sesuaikan dua angka ini sebagai satu pasang — jangan ubah salah satu
   saja.
3. **Kalau build gagal karena resource/RAM habis**, turunkan dulu scope:
   aku bisa buatkan versi tanpa `material-icons-extended` (pakai ikon
   bawaan yang lebih ringan) kalau itu jadi masalah.
4. Aku **tidak bisa menjalankan build ini di sisiku** (sandbox tanpa
   akses internet/Android SDK), jadi kode ini belum pernah benar-benar
   dikompilasi. Kirim log error pertama yang muncul kalau ada, dan aku
   bantu perbaiki — jangan upgrade banyak versi sekaligus sebelum tahu
   akar masalahnya.

## Langkah build

1. Di Android IDE kamu, buat project baru: **Empty Activity (Compose)**,
   bahasa Kotlin, package `com.selaras.circle`, minSdk 24. Ini supaya
   Gradle wrapper, `local.properties`, dan ikon launcher default
   ter-generate otomatis dengan benar oleh IDE-mu.
2. Timpa `settings.gradle.kts`, `build.gradle.kts` (root), dan
   `app/build.gradle.kts` dengan isi dari paket ini.
3. Timpa `app/src/main/AndroidManifest.xml` dan `app/src/main/res/values/*`.
4. Salin seluruh folder `app/src/main/java/com/selaras/circle/` ke
   project kamu (timpa `MainActivity.kt` default-nya).
5. Sync Gradle (biasanya tombol "Sync" atau otomatis saat membuka project).
6. Build & run:
   - Lewat terminal/Gradle wrapper (kalau IDE kamu menyediakannya):
     ```
     ./gradlew assembleDebug
     ```
   - Atau lewat tombol Run/Build bawaan IDE kamu.
7. Output APK debug ada di `app/build/outputs/apk/debug/app-debug.apk`
   (verifikasi path sebenarnya dari output build-mu).

## Checklist uji fungsional

- [ ] Tab "Masuk"/"Daftar" di layar login berpindah dengan benar.
- [ ] Tombol mata di field password menampilkan/menyembunyikan teks.
- [ ] Tombol "Masuk" membawa ke layar utama (Beranda).
- [ ] Swipe kiri/kanan antar 5 tab (Beranda, Peringkat, Misi, Toko,
      Profil) terasa smooth, dan pill di bottom nav ikut bergeser.
- [ ] Tap ikon bottom nav juga memindahkan halaman (animasi, bukan loncat).
- [ ] Di tab Misi: klaim misi yang progress-nya penuh menambah koin/permata.
- [ ] Roda keberuntungan berputar dan berhenti di posisi acak, lalu
      menampilkan hadiah.
- [ ] Tombol "Keluar" di Profil mengembalikan ke layar login.
- [ ] Rotasi layar: koin, permata, misi yang sudah diklaim, dan item toko
      yang sudah dibeli **tetap sama**; tab aktif tetap (pager menyimpan
      halamannya sendiri); isi username di Login tetap.
- [ ] Misi 1 (1/1) tombol "Klaim" aktif → klik → koin +50, tombol jadi "Diklaim"
      dan tidak bisa diklik lagi. Misi 2 (2/3) dan 3 (0/1) tetap terkunci.
- [ ] Roda: koin turun 50 segera; saat berhenti, segmen di bawah penunjuk
      sesuai hadiah yang tertulis; saldo naik sesuai hadiah. Tombol nonaktif
      selama berputar.
- [ ] Toko: beli Bingkai (650 koin) → saldo turun, tombol jadi "Dimiliki".
      Kaos (1200) dan seterusnya bisa sampai "Koin kurang" setelah koin habis.
- [ ] Putar layar *saat roda berputar*: tidak crash, hadiah tetap dibayar
      satu kali.
- [ ] Unit test: `./gradlew testDebugUnitTest` (8 tes di `GameStateTest`).

## Catatan performa & keamanan

- State sekarang bertahan **rotasi**, tapi belum bertahan jika proses app
  dimatikan sistem atau app ditutup (ViewModel biasa, bukan
  `SavedStateHandle`/Room). Logout lalu masuk lagi akan mereset state
  karena ViewModel ikut dibuang bersama layar Beranda.
- `GlassBackdrop` memakai blur `RenderEffect` pada Canvas yang beranimasi
  terus-menerus. Di HP RAM kecil ini kandidat bottleneck pertama — ukur
  dulu (mis. Profile GPU Rendering / Macrobenchmark) sebelum mengubahnya.
- Tidak ada secret/API key/signing credential di kode ini — aman untuk
  disimpan di repo publik.
- Daftar dependency sengaja minimal: Compose BOM, Navigation-Compose,
  dan Material Icons Extended. Tidak ada library jaringan/analytics.
- Belum ada pengukuran startup time/APK size nyata — angka-angka itu
  harus diukur dari build asli di device kamu, bukan ditebak di sini.

## Rencana lanjutan (opsional, bertahap sesuai skill)

- Selesai: ViewModel + state tahan rotasi.
- Berikutnya yang masuk akal: **Room** untuk simpan saldo/misi/pembelian
  offline (GameState sudah immutable & terpusat, jadi mudah dipetakan),
  lalu halaman detail acara. Beri tahu aku mau lanjut ke yang mana dulu — supaya tetap
  satu fitur teruji sebelum nambah fitur berikutnya, sesuai alur
  baseline → fitur → build → optimasi di skill ini.
